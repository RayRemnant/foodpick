//
//  UIViewController+Alert.swift
//  Health App
//
//  Created by Marius Lazar on 16/08/22.
//

import UIKit

extension UIViewController {
    func showError(_ error: Error, completion: (() -> Void)? = nil) {
        let alertController = UIAlertController(
            title: "ERROR",
            message: error.localizedDescription.debugDescription,
            preferredStyle: .alert
        )
        
        let okAction = UIAlertAction(
            title: "OK",
            style: .cancel,
            handler: { _ in
                completion?()
            }
        )
        
        alertController.addAction(okAction)
        
        present(alertController, animated: true)
    }
    
    func showWarning(_ message: String, completion: (() -> Void)? = nil) {
        let alertController = UIAlertController(
            title: "WARNING",
            message: message,
            preferredStyle: .alert
        )
        
        let okAction = UIAlertAction(
            title: "OK",
            style: .cancel,
            handler: { _ in
                completion?()
            }
        )
        
        alertController.addAction(okAction)
        
        present(alertController, animated: true)
    }
}
