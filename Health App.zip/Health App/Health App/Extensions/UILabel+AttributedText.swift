import UIKit

extension UILabel {
    private static let defaultFont = UIFont.self
    
    @discardableResult
    func resetAttributeText() -> Self {
        _allAttributedStrings = []
        attributedText = nil
        
        return self
    }
    
    @discardableResult
    func appendAttributeText(_ text: String?, withUnderline: Bool = false) -> Self {
        guard let text = text else {
            return self
        }
        
        let attributeText: NSAttributedString
        
        if withUnderline {
            attributeText = NSAttributedString(
                string: text,
                attributes: [
                    .underlineStyle: NSUnderlineStyle.single.rawValue
                ]
            )
            
        } else {
            attributeText = NSAttributedString(string: text)
        }
        
        updateAttributeText(attributeText)
        
        return self
    }
    
    @discardableResult
    func updateAttributeText(fontSize: CGFloat, weight: UIFont.Weight) -> Self {
        let attributes: [NSAttributedString.Key: Any] = [
            .font: Self.defaultFont.systemFont(ofSize: fontSize, weight: weight)
        ]
        
        updateAttributes(attributes)
        
        return self
    }
    
    @discardableResult
    func updateAttributeText(color: UIColor) -> Self {
        let attributes: [NSAttributedString.Key: Any] = [
            .foregroundColor: color
        ]
        
        updateAttributes(attributes)
        
        return self
    }
    
    @discardableResult
    func appendAttributeText(image: UIImage?) -> Self {
        let imageAttachment = NSTextAttachment()
        imageAttachment.image = image
        
        let imageAttributString = NSAttributedString(attachment: imageAttachment)
        
        updateAttributeText(imageAttributString)
        
        return self
    }
}

extension UILabel {
    private struct _AttributedString {
        static var key = "UILabel_AttributedString"
    }
    
    private var _allAttributedStrings: [NSAttributedString] {
        get { objc_getAssociatedObject(self, &_AttributedString.key) as? [NSAttributedString] ?? [] }
        set { objc_setAssociatedObject(self, &_AttributedString.key, newValue, .OBJC_ASSOCIATION_RETAIN_NONATOMIC) }
    }
    
    private func updateAttributes(_ attributes: [NSAttributedString.Key: Any]) {
        guard !_allAttributedStrings.isEmpty else {
            return
        }
        
        let mutableAttributeString = NSMutableAttributedString(
            attributedString: _allAttributedStrings.last!
        )
        
        let title = mutableAttributeString.string
        
        mutableAttributeString.addAttributes(
            attributes,
            range: NSRange(location: 0, length: title.count)
        )
        
        _allAttributedStrings.removeLast()
        _allAttributedStrings.append(mutableAttributeString)
        
        let reduced = _allAttributedStrings.reduce(NSMutableAttributedString()) { result, attribute in
            result.append(attribute)
            
            return result
        }
        
        attributedText = reduced
    }
    
    private func updateAttributeText(_ attributedString: NSAttributedString) {
        _allAttributedStrings.append(attributedString)
        
        let reduced = _allAttributedStrings.reduce(NSMutableAttributedString()) { result, attribute in
            result.append(attribute)
            
            return result
        }
        
        attributedText = reduced
    }
}
