//
//  CameraViewController.swift
//  Health App
//
//  Created by Marius Lazar on 16/08/22.
//

import UIKit
import AVFoundation

class CameraViewController: UIViewController {
    @IBOutlet private weak var rectangleView: UIView!
    
    private lazy var metadataOutput = AVCaptureMetadataOutput()
    var captureSession: AVCaptureSession?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setup()
        setupCaptureSession()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        captureSession?.startRunning()
    }
    
    private func setup() {
        rectangleView.backgroundColor = .clear
        rectangleView.layer.cornerRadius = 8.0
        rectangleView.layer.borderWidth = 2.0
        rectangleView.layer.borderColor = UIColor.systemGray3.cgColor
    }
    
    private func debug() {
        fetchProduct(code: "3017620422003")
    }

    private func setupCaptureSession() {
        captureSession = AVCaptureSession()
        
        guard let captureSession = captureSession else {
            return
        }

        guard
            let device = AVCaptureDevice.default(for: .video),
            let videoInput = try? AVCaptureDeviceInput(device: device),
            captureSession.canAddInput(videoInput),
            captureSession.canAddOutput(metadataOutput)
                
        else { return }
        
        captureSession.addInput(videoInput)
        captureSession.addOutput(metadataOutput)
        
        metadataOutput.setMetadataObjectsDelegate(self, queue: .main)
        metadataOutput.metadataObjectTypes = [.ean8, .ean13, .pdf417]
        
        let previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.frame = view.layer.bounds
        previewLayer.videoGravity = .resizeAspectFill
        
        view.layer.insertSublayer(previewLayer, at: 0)
        
        captureSession.startRunning()
    }
    
    private func showAlert(with metadataMessage: String, completion: @escaping () -> Void) {
        captureSession?.stopRunning()
        
        let alertController = UIAlertController(
            title: "BARCODE",
            message: metadataMessage,
            preferredStyle: .alert
        )
        
        let okAction = UIAlertAction(
            title: "OK",
            style: .cancel,
            handler: { _ in
                completion()
            }
        )
        
        alertController.addAction(okAction)
        
        present(alertController, animated: true)
    }
    
    func fetchProduct(code: String) {
        captureSession?.stopRunning()
        
        Network.product(code: code).fetch { [weak self] (result: Result<ProductCodeResponse, Error>) in
            guard let self = self else {
                return
            }

            switch result {
            case .success(let productCode):
                if let product = productCode.product {
                    self.showProductDetail(product)
                    
                } else {
                    self.showWarning("Product not found") {
                        self.captureSession?.startRunning()
                    }
                }
                
            case .failure(let error):
                self.showError(error) {
                    self.captureSession?.startRunning()
                }
            }
        }
    }
    
    func showProductDetail(_ product: Product) {
        let productVC = ProductDetailViewController()
        productVC.loadProduct(product)
        
        navigationController?.pushViewController(productVC, animated: true)
    }
}

extension CameraViewController: AVCaptureMetadataOutputObjectsDelegate {
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        guard
            let object = metadataObjects.first,
            let stringValue = object.value(forKey: "stringValue") as? String
                
        else { return }
        
        fetchProduct(code: stringValue)
    }
}

