//
//  ProductDetailViewController.swift
//  Health App
//
//  Created by Marius Lazar on 16/08/22.
//

import UIKit

class ProductDetailViewController: UIViewController {
    @IBOutlet private weak var titleLabel: UILabel!
    
    @IBOutlet private weak var topImageView: UIImageView!
    @IBOutlet private weak var ingredientsLabel: UILabel!
    @IBOutlet private weak var allergensLabel: UILabel!
    @IBOutlet private weak var hStackView: UIStackView!
    
    @IBOutlet private weak var fatStackView: UIStackView!
    @IBOutlet private weak var fatCircleView: UIView!
    @IBOutlet private weak var fatLabel: UILabel!
    
    @IBOutlet private weak var saturatedFatStackView: UIStackView!
    @IBOutlet private weak var saturatedFatCircleView: UIView!
    @IBOutlet private weak var saturatedFatLabel: UILabel!
    
    @IBOutlet private weak var sugarsStackView: UIStackView!
    @IBOutlet private weak var sugarsCircleView: UIView!
    @IBOutlet private weak var sugarsLabel: UILabel!
    
    @IBOutlet private weak var saltStackView: UIStackView!
    @IBOutlet private weak var saltCircleView: UIView!
    @IBOutlet private weak var saltLabel: UILabel!
    
    var product: Product?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupUI()
    }
    
    private func setupUI() {
        guard let product = product else {
            return
        }
        
        let name = product.name ?? ""
        let quantity = product.quantity ?? ""
        
        titleLabel.text = name + " " + "(\(quantity))"
        
        ingredientsLabel.resetAttributeText()
        if let ingredients = product.ingredients {
            ingredientsLabel
                .appendAttributeText("Ingredients:")
                .updateAttributeText(fontSize: 16.0, weight: .semibold)
                .appendAttributeText(" ")
                .appendAttributeText(ingredients.uppercased())
                .updateAttributeText(fontSize: 16.0, weight: .regular)
        }
           
        allergensLabel.resetAttributeText()
        if let allergens = product.allergens {
            allergensLabel
                .appendAttributeText("Allergens:")
                .updateAttributeText(fontSize: 16.0, weight: .semibold)
                .appendAttributeText(" ")
                .appendAttributeText(allergens
                    .lowercased()
                    .replacingOccurrences(of: "en:", with: "")
                    .replacingOccurrences(of: "it:", with: "")
                    .uppercased()
                )
                .updateAttributeText(fontSize: 16.0, weight: .regular)
        }
        
        fetch(url: product.novaGroupImageURL)
        fetch(url: product.nutriscoreGradeImageURL)
        
        topImageView.isHidden = product.imageFront == nil
        if let imageUrlString = product.imageFront, let imageURL = URL(string: imageUrlString) {
            fetch(url: imageURL, assignTo: topImageView)
        }
        
        [fatStackView, saturatedFatStackView, sugarsStackView, saltStackView].forEach {
            $0?.isHidden = true
        }
        
        if let fatText = product.nutrientLevels.fat {
            fatStackView.isHidden = false
            
            setCircleViewColor(fatCircleView, text: fatText)
            fatLabel.resetAttributeText()
            if let fat100g = product.nutriments.fat100g {
                fatLabel
                    .appendAttributeText("\(fat100g)" + "g")
                    .updateAttributeText(fontSize: 16.0, weight: .regular)
                    .appendAttributeText(" ")
                    .appendAttributeText("fat in")
            }
            
            fatLabel
                .appendAttributeText(" ")
                .appendAttributeText(fatText + " " + "quantity")
                .updateAttributeText(fontSize: 16.0, weight: .semibold)
        }
        
        if let saturatedFatText = product.nutrientLevels.saturatedFat {
            saturatedFatStackView.isHidden = false
            
            setCircleViewColor(saturatedFatCircleView, text: saturatedFatText)
            saturatedFatLabel.resetAttributeText()
            if let saturatedFat100g = product.nutriments.saturatedFat100g {
                saturatedFatLabel
                    .appendAttributeText("\(saturatedFat100g)" + "g")
                    .updateAttributeText(fontSize: 16.0, weight: .regular)
                    .appendAttributeText(" ")
                    .appendAttributeText("saturated fat in")
            }
            
            saturatedFatLabel
                .appendAttributeText(" ")
                .appendAttributeText(saturatedFatText + " " + "quantity")
                .updateAttributeText(fontSize: 16.0, weight: .semibold)
        }
        
        if let sugarsText = product.nutrientLevels.sugars {
            sugarsStackView.isHidden = false
            
            setCircleViewColor(sugarsCircleView, text: sugarsText)
            sugarsLabel.resetAttributeText()
            if let sugars100g = product.nutriments.sugars100g {
                sugarsLabel
                    .appendAttributeText("\(sugars100g)" + "g")
                    .updateAttributeText(fontSize: 16.0, weight: .regular)
                    .appendAttributeText(" ")
                    .appendAttributeText("salt in")
            }
            
            sugarsLabel
                .appendAttributeText(" ")
                .appendAttributeText(sugarsText + " " + "quantity")
                .updateAttributeText(fontSize: 16.0, weight: .semibold)
        }
        
        if let saltText = product.nutrientLevels.salt {
            saltStackView.isHidden = false
            
            setCircleViewColor(saltCircleView, text: saltText)
            saltLabel.resetAttributeText()
            if let salt100g = product.nutriments.salt100g {
                saltLabel
                    .appendAttributeText("\(salt100g)" + "g")
                    .updateAttributeText(fontSize: 16.0, weight: .regular)
                    .appendAttributeText(" ")
                    .appendAttributeText("salt in")
            }
            
            saltLabel
                .appendAttributeText(" ")
                .appendAttributeText(saltText + " " + "quantity")
                .updateAttributeText(fontSize: 16.0, weight: .semibold)
        }
        
        debugPrint(product.nutriments.saturatedFat100g ?? 0.0)
    }
    
    private func setCircleViewColor(_ circleView: UIView?, text: String) {
        if text == "high" {
            circleView?.backgroundColor = .systemRed
            
        } else if text == "low" {
            circleView?.backgroundColor = .systemGreen
            
        } else {
            circleView?.backgroundColor = .systemGray3
        }
    }
    
    private func fetch(url: URL?, assignTo view: UIImageView? = nil) {
        guard let url = url else {
            return
        }
        
        NetworkImage.image(url: url).fetchImage { [weak self] (result: (Result<UIImage, Error>)) in
            guard let self = self else {
                return
            }
            
            switch result {
            case .success(let image):
                let imageView = UIImageView()
                imageView.contentMode = .scaleAspectFit
                imageView.image = image
                
                if let view = view {
                    view.image = image
                    
                } else {
                    self.hStackView.addArrangedSubview(imageView)
                }
                
            case .failure(let error):
                self.showError(error)
            }
        }
    }
}

extension ProductDetailViewController {
    func loadProduct(_ product: Product) {
        self.product = product
    }
}
