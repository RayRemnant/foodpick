//
//  ViewCircle.swift
//  Health App
//
//  Created by Marius Lazar on 17/08/22.
//

import UIKit

class ViewCircle: UIView {

    override func layoutSubviews() {
        super.layoutSubviews()
        
        layer.cornerRadius = bounds.height / 2
    }

}
