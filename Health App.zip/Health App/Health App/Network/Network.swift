//
//  Network.swift
//  Health App
//
//  Created by Marius Lazar on 16/08/22.
//

import Foundation
import UIKit

enum Network {
    case product(code: String)
    
    func fetch<D: Decodable>(completion: @escaping (Result<D, Error>) -> Void) {
        var url = URL(string: "https://world.openfoodfacts.org/api/v2/")!
        
        switch self {
        case .product(let code):
            url.appendPathComponent("product/\(code)/")
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data else {
                return
            }
            
            do {
                let object = try JSONDecoder().decode(D.self, from: data)
                
                if let dataString = String(data: data, encoding: .utf8) {
                    print("⬇️", dataString, "⬇️")
                }
                
                DispatchQueue.main.async {
                    completion(.success(object))
                }
                
            } catch {
                DispatchQueue.main.async {
                    print(error)
                    
                    completion(.failure(error))
                }
            }
        }
        .resume()
    }
}

enum NetworkImage {
    case image(url: URL)
    
    func fetchImage(completion: @escaping (Result<UIImage, Error>) -> Void) {
        guard case .image(let url) = self else {
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data else {
                return
            }
                
            if let image = UIImage(data: data) {
                DispatchQueue.main.async {
                    completion(.success(image))
                }
                
            } else {
                DispatchQueue.main.async {
                    completion(.failure(CustomError.generic))
                }
            }
        }
        .resume()
    }
}

enum CustomError: Error {
    case generic
}
