//
//  ProductCodeResponse.swift
//  Health App
//
//  Created by Marius Lazar on 16/08/22.
//

import Foundation

typealias Product = ProductCodeResponse.Product

struct ProductCodeResponse: Decodable {
    let product: Product?
    
    enum CodingKeys: String, CodingKey {
        case product = "product"
    }
}

extension ProductCodeResponse {
    struct Product: Decodable {
        let name: String?
        let quantity: String?
        let allergens: String?
        let ingredients: String?
        let novaGroup: Int?
        // novaGroup IMAGES
        // https://static.openfoodfacts.org/images/attributes/nova-group-{{nova_group}}.svg
        
        let nutriscoreGrade: String?
        // nutriscore_grade IMAGES
        // https://static.openfoodfacts.org/images/attributes/nutriscore-{{nutriscore_grade}}.svg
        
        let imageFront: String?
        let nutrientLevels: NutrientLevels
        let nutrientLevelsTags: [String]
        let nutriments: Nutriments
        
        let labelsHierarchy: [String]
        
        enum CodingKeys: String, CodingKey {
            case name = "product_name"
            case quantity
            case allergens
            case ingredients = "ingredients_text"
            case novaGroup = "nova_group"
            case nutriscoreGrade = "nutriscore_grade"
            case imageFront = "image_front_url"
            case nutrientLevels = "nutrient_levels"
            case nutrientLevelsTags = "nutrient_levels_tags"
            case nutriments = "nutriments"
            case labelsHierarchy = "labels_hierarchy"
        }
        
        var novaGroupImageURL: URL? {
            if let novaGroup = novaGroup {
                return URL(string: "https://static.openfoodfacts.org/images/attributes/nova-group-\(novaGroup).png")
            }
            
            return nil
        }
        
        var nutriscoreGradeImageURL: URL? {
            if let nutriscoreGrade = nutriscoreGrade {
                return URL(string: "https://static.openfoodfacts.org/images/attributes/nutriscore-\(nutriscoreGrade).png")
            }
            
            return nil
        }
        
        var description: String {
            return """
            labelsHierarchy = \(labelsHierarchy.description)
            
            novaGroupTag IMMAGES = https://static.openfoodfacts.org/images/attributes/nova-group-\(novaGroup ?? -1).svg
            
            nutriscoreGrade IMMAGES = https://static.openfoodfacts.org/images/attributes/nutriscore-\(nutriscoreGrade ?? "NOPE").svg
            """
        }
    }
    
    struct NutrientLevels: Decodable {
        let fat: String?
        let salt: String?
        let saturatedFat: String?
        let sugars: String?
        
        enum CodingKeys: String, CodingKey {
            case fat
            case salt
            case saturatedFat = "saturated-fat"
            case sugars
        }
    }
    
    struct Nutriments: Decodable {
        let fat100g: Float?
        let proteins100g: Float?
        let saturatedFat100g: Float?
        let sugars100g: Float?
        let salt100g: Float?
        
        enum CodingKeys: String, CodingKey {
            case fat100g = "fat_100g"
            case proteins100g = "proteins_100g"
            case saturatedFat100g = "saturated-fat_100g"
            case sugars100g = "sugars_100g"
            case salt100g = "salt_100g"
        }
    }
}
